const {
    default: makeWASocket,
    Browsers,
    AnyMessageContent,
    delay,
    proto,
    generateWAMessageFromContent,
    DisconnectReason,
    fetchLatestBaileysVersion,
    useSingleFileAuthState,
  } = require('@adiwajshing/baileys'),
  fs = require('fs'),
  P = require('pino'),
  { exec, spawn, execSync } = require('child_process'),
  { Boom } = require('@hapi/boom'),
  { wait, simih, getBuffer, h2k } = require('./lib/functions'),
  { fetchJson, fetchText } = require('./lib/fetcher'),
  chalkanim = require('chalk-animation'),
  package = require('./package.json'),
  CFonts = require('cfonts'),
  canvas = require('discord-canvas'),
  { state, saveState } = useSingleFileAuthState('./session.json'),
  startNayla = async () => {
    let { version, isLatest }  = await fetchLatestBaileysVersion()
    CFonts.say('BOTZ26', {
      font: 'simpleBlock',
      align: 'center',
      colors: ['greenBright'],
      background: 'transparent',
      letterSpacing: 1,
      space: true,
    })
    CFonts.say('BY YT RIMURUBOTZ\nJANGAN DIPERJUALBELIKAN', {
      font: 'console',
      align: 'center',
      colors: ['greenBright'],
      background: 'transparent',
      letterSpacing: 1,
      space: true,
    })
    const rndyclient = makeWASocket({
      version: [2, 2210, 9],
      logger: P({ level: 'silent' }),
      printQRInTerminal: true,
      auth: state,
      browser: ['RndyTech', 'Chrome', '3.0.0'],
    })
    
    rndyclient.ev.on('messages.upsert', async ({ messages: rndymsg }) => {
      const rndyupsert = rndymsg[0]
      if (rndyupsert.fromMe) {
        return
      }
      require('./nayla')(rndyclient, rndyupsert)
    })
    rndyclient.ev.on('group-participants.update', async (rndyact) => {
    	console.log(rndyact)
    	const metadata = await rndyclient.groupMetadata(rndyact.id)
    grupname = metadata.subject
      const rndygrp = rndyact.participants[0]
      let arrmem = rndyact.participants.length
      
      if (rndyact.action == 'add') {
      	console.log(rndyact)
                try {
        	getpp = rndygrp.split("@")[0]+ '@c.us'
 ppimg = await rndyclient.profilePictureUrl(getpp, 'image')
        } catch {
          ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
        }


const welcomer = await new canvas.Welcome()
                    .setUsername(rndygrp.split("@")[0])
                    .setDiscriminator(grupname)
                    .setMemberCount(grupname)
                    .setGuildName(grupname)
                    .setAvatar(ppimg)
                    .setColor('border', '#00100C')
                    .setColor('username-box', '#00100C')
                    .setColor('discriminator-box', '#00100C')
                    .setColor('message-box', '#00100C')
                    .setColor('title', '#00FFFF')
                    .setBackground('https://www.photohdx.com/images/2016/05/red-blurry-background.jpg')
                    .toAttachment()
                const base64 = `data:image/png;base64,${welcomer.toBuffer().toString('base64')}`
                await rndyclient.sendFile(rndyact.id, base64, 'welcome.png', `Welcome ${pushname}!`)
      }
      if (rndyact.action == 'remove') {
      	console.log(rndyact)
                try {
        	getpp = rndygrp.split("@")[0]+ '@c.us'
 ppimg = await rndyclient.profilePictureUrl(getpp, 'image')
        } catch {
          ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
        }

nyz3 = await getBuffer(ppimg)
                mbc = `
SELAMAT DATANG
GRUP : ${grupname}
NOMOR : ${rndygrp.split("@")[0]}
MEMBER : ${arrmem} ORANG

SILAHKAN PENCET MENU DI BAWAH!
`


const sections = [
    {
    title: "Section 1",
    rows: [
        {title: "Option 1", rowId: "option1"},
        {title: "Option 2", rowId: "option2", description: "This is a description"}
    ]
    },
   {
    title: "Section 2",
    rows: [
        {title: "Option 3", rowId: "option3"},
        {title: "Option 4", rowId: "option4", description: "This is a description V2"}
    ]
    },
]

const listMessage = {
	image: nyz3,
  text: "This is a list",
  footer: "nice footer, link: https://google.com",
  title: "Amazing boldfaced list title",
  buttonText: "Required, text on the button to view the list",
  sections
}





const templateButtons = [
    {index: 1, urlButton: {displayText: 'REST API SAYA', url: 'https://rndyxd.my.id/'}},
    {index: 3, quickReplyButton: {displayText: 'OWNER', id: '.owner'}},
]

const templateMessage = {
    text: `
HALO👋 ${rndygrp.split("@")[0]},
 Saya adalah RndyBotz yang di buat oleh RndyTech untuk membantu anda mengelolah hosting anda



TEKAN TOMBOL DI BAWAH UNTUK MELIHAT MENU`,
    footer: 'BOT by RndyBotz',
    templateButtons: templateButtons
}

let buttons = [
{buttonId: `menu`, buttonText: {displayText: 'OKE'}, type: 1}
]
let buttonMessage = {
image: nyz3,
caption: mbc,
footer: "BOT by RndyBotz",
mentions:[getpp],
buttons: buttons,
headerType: 4,
}

rndyclient.sendMessage(rndyact.id, buttonMessage)  
//rndyclient.sendMessage(rndyact.id, templateMessage)
rndyclient.sendMessage(rndyact.id, listMessage)
      }
if (rndyact.action == 'promote') {
      	console.log(rndyact)
                try {
        	getpp = rndygrp.split("@")[0]+ '@c.us'
 ppimg = await rndyclient.profilePictureUrl(getpp, 'image')
        } catch {
          ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
        }

nyz3 = await getBuffer(ppimg)
                mbc = `
SELAMAT DATANG
GRUP : ${grupname}
NOMOR : ${rndygrp.split("@")[0]}
MEMBER : ${arrmem} ORANG

SILAHKAN PENCET MENU DI BAWAH!
`


const sections = [
    {
    title: "Section 1",
    rows: [
        {title: "Option 1", rowId: "option1"},
        {title: "Option 2", rowId: "option2", description: "This is a description"}
    ]
    },
   {
    title: "Section 2",
    rows: [
        {title: "Option 3", rowId: "option3"},
        {title: "Option 4", rowId: "option4", description: "This is a description V2"}
    ]
    },
]

const listMessage = {
	image: nyz3,
  text: "This is a list",
  footer: "nice footer, link: https://google.com",
  title: "Amazing boldfaced list title",
  buttonText: "Required, text on the button to view the list",
  sections
}





const templateButtons = [
    {index: 1, urlButton: {displayText: 'REST API SAYA', url: 'https://rndyxd.my.id/'}},
    {index: 3, quickReplyButton: {displayText: 'OWNER', id: '.owner'}},
]

const templateMessage = {
    text: `
HALO👋 ${rndygrp.split("@")[0]},
 Saya adalah RndyBotz yang di buat oleh RndyTech untuk membantu anda mengelolah hosting anda



TEKAN TOMBOL DI BAWAH UNTUK MELIHAT MENU`,
    footer: 'BOT by RndyBotz',
    templateButtons: templateButtons
}

let buttons = [
{buttonId: `menu`, buttonText: {displayText: 'OKE'}, type: 1}
]
let buttonMessage = {
image: nyz3,
caption: mbc,
footer: "BOT by RndyBotz",
mentions:[getpp],
buttons: buttons,
headerType: 4,
}

rndyclient.sendMessage(rndyact.id, buttonMessage)  
//rndyclient.sendMessage(rndyact.id, templateMessage)
rndyclient.sendMessage(rndyact.id, listMessage)
      }
      
      
      
      
      if (rndyact.action == 'demote') {
        try {
        	getpp = rndygrp.split("@")[0]+ '@c.us'
ppimg = await rndyclient.profilePictureUrl(getpp, 'image')
        } catch {
          ppimg = 'https://i0.wp.com/www.gambarunik.id/wp-content/uploads/2019/06/Top-Gambar-Foto-Profil-Kosong-Lucu-Tergokil-.jpg'
        }

nyz3 = await getBuffer(ppimg)
                mbc = `
KELUAR DARI GRUP ${grupname}
SEMOGA ${rndygrp.split("@")[0]}
DI TERIMA DI SISINYA
`
let buttons = [
{buttonId: `menu`, buttonText: {displayText: 'OKE'}, type: 1}
]
let buttonMessage = {
image: nyz3,
caption: mbc,
footer: "BOT by RndyBotz",
mentions:[getpp],
buttons: buttons,
headerType: 4,
}
rndyclient.sendMessage(rndyact.id, buttonMessage)  
        
        
        
      }
    })
    nomerother = '6282347260729'
    rndyclient.ev.on('connection.update', (rndyupt) => {
      if (rndyupt.connection === 'open') {
        console.log(
          'Sukses connect, nomer bot => ' + rndyclient.user.id.split(':')[0]
        )
      } else {
        if (rndyupt.connection === 'close') {
          startNayla()
        }
      }
    })
    rndyclient.ev.on('creds.update', saveState)
  }
startNayla()
