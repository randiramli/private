exports.iklan1 = () => {
  return `[ YOUR_IKLAN ]`
};

exports.iklan2 = () => {
  return `[ YOUR_IKLAN ]`
};

exports.iklan3 = () => {
  return `[ YOUR_IKLAN ]`
};
