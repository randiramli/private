// PUNYA SAYA [ RIMURUBOTZ ] JANGAN UBAH THX TO YA
// DILARANG DI PERJUAL BELIKAN
const respon = require('./lib/respon.js');
const iklan = require('./admin/iklan.js');
const { MessageOptions, Mimetype, generateWAMessageFromContent, MessageType, proto, generateWAMessage, downloadContentFromMessage } = require('@adiwajshing/baileys');
const { color, bgcolor } = require('./lib/color')
const fs = require('fs');
const imgbb = require('imgbb-uploader')
const hx = require('hxz-api');
const ffmpeg = require('fluent-ffmpeg')
const chalkanim = require('chalk-animation');
const moment = require("moment-timezone");
const { exec, spawn } = require("child_process")
const { fetch, downloadSaveImgMsg } = require('./lib/anu.js');
const { wait, simih, getBuffer, h2k } = require('./lib/functions')
const { fetchJson, fetchText } = require('./lib/fetcher')
const { recognize } = require('./lib/ocr')
const session = require('./session.json');
moment.tz.setDefault('Asia/Jakarta').locale("id");
const setting = JSON.parse(fs.readFileSync('./admin/settings.json')) 
bahasa = "id"
apa = "other"
const prem = []
const antilink = []
const antitag = []
const antivirtex = [] 
prefix = setting.prefix
const { namabot, kodeprem, instagram, youtube, namaowner, linkgrub, nomerowner, gopay, dana, pulsa, donasi } = setting
function kyun(seconds){
function pad(s){
return (s < 10 ? '0' : '') + s;
}
var hours = Math.floor(seconds / (60*60));
var minutes = Math.floor(seconds % (60*60) / 60);
var seconds = Math.floor(seconds % 60);
return `${pad(hours)} : ${pad(minutes)} : ${pad(seconds)}`}
runtime = process.uptime()
const sleep = async (ms) => {
return new Promise(resolve => setTimeout(resolve, ms));
}
module.exports = hehe = async (nayla, nay, store) => {
try {
const type = Object.keys(nay.message)[0];
const body = (type === 'conversation') ? nay.message.conversation : (type == 'imageMessage') ? nay.message.imageMessage.caption : (type == 'videoMessage') ? nay.message.videoMessage.caption : (type == 'extendedTextMessage') ? nay.message.extendedTextMessage.text : (type == 'buttonsResponseMessage') ? nay.message.buttonsResponseMessage.selectedButtonId : (type == 'listResponseMessage') ? nay.message.listResponseMessage.singleSelectReply.selectedRowId : (type == 'templateButtonReplyMessage') ? nay.message.templateButtonReplyMessage.selectedId : (type === 'messageContextInfo') ? (nay.message.buttonsResponseMessage?.selectedButtonId || nay.message.listResponseMessage?.singleSelectReply.selectedRowId || nay.text) : ''
const budy = (type === 'conversation') ? nay.message.conversation : (type === 'extendedTextMessage') ? nay.message.extendedTextMessage.text : ''
const isCommand = body.startsWith(prefix);
const command = body.slice(1).trim().split(/ +/).shift().toLowerCase()
const command1 = body.slice(5).trim().split(/ +/).shift().toLowerCase()
const cmd = isCommand ? body.slice(1).trim().split(/ +/).shift().toLowerCase() : null;
const isCmd = body.startsWith(prefix)
const time = moment(new Date()).format("HH:mm");
const text = nay.message.conversation;
const isGroup = nay.key.remoteJid.endsWith('@g.us');
const from = nay.key.remoteJid;
const content = JSON.stringify(nay.message);
const args = body.trim().split(/ +/).slice(1);
const q = args.join(" ");
const botNumber = nayla.user.id.split(':')[0] + '@s.whatsapp.net';
const ownerNumber = [`${nomerowner}@s.whatsapp.net`]
const botName = nayla.user.name;
const pushname = nay.pushName;
const sender = isGroup ? (nay.key.participant ? nay.key.participant : nay.participant) : nay.key.remoteJid;
const groupMetadata = isGroup ? await nayla.groupMetadata(from) : '';
const uwong = isGroup ? await groupMetadata.participants : '';
const groupAdmins = isGroup ? await uwong.filter(v => v.admin !== null).map(a => a.id) : '';
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false;
const isGroupAdmins = groupAdmins.includes(sender) || false;
const groupName = isGroup ? groupMetadata.subject : "";
const isOwner = ownerNumber.includes(sender)
const isPrem = prem.includes(sender) || isOwner	
const isAntiLink = isGroup ? antilink.includes(from) : false 
const isAntiVirtex = isGroup ? antivirtex.includes(from) : false 
const isAntitag = isGroup ? antitag.includes(from) : false 			
const isMedia = (type === 'imageMessage' || type === 'videoMessage');
const isQuotedImage = type === 'extendedTextMessage' && content.includes('imageMessage');
const isQuotedVideo = type === 'extendedTextMessage' && content.includes('videoMessage');
const isQuotedSticker = type === 'extendedTextMessage' && content.includes('stickerMessage');
await nayla.sendReadReceipt(from, nay.key.participant, [nay.key.id]);
fake = fs.readFileSync(`./media/image/fake.jpg`)
nay1 = { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: {
        "imageMessage": {
            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
            "mimetype": "image/jpeg",
            "caption": 'Bot by RndyBotz',
            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
            "fileLength": "28777",
            "height": 1080,
            "width": 1079,
            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
            "mediaKeyTimestamp": "1610993486",
            "jpegThumbnail": fs.readFileSync(`./media/image/error.jpg`),
            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
        }
    }}
if (!isGroup && isCommand) console.log('\x1b[1;31m=\x1b[1;37m>', '[\x1b[1;32m=>\x1b[1;37m]', color(`[ CMD ]`, 'yellow'), color('NAME', 'red'), color(pushname, 'yellow'), color('SEDANG', 'white'), color('MENGGUNAKAN', 'yellow'), color('FITUR', 'red'), color('=>', 'yellow'), color(command), 'DI :', color('PESAN PRIBADI', 'yellow')) 
if (isCommand && isGroup) console.log('\x1b[1;31m=\x1b[1;37m>', '[\x1b[1;32m=>\x1b[1;37m]', color(`[ CMD ]`, 'yellow'), color('NAME', 'red'), color(pushname, 'yellow'), color('SEDANG', 'white'), color('MENGGUNAKAN', 'yellow'), color('FITUR', 'red'), color('=>', 'yellow'), color(command), 'DI :', color(groupName, 'yellow'))	  
const mentions = (teks, memberr, id) => {(id == null || id == undefined || id == false) ? nayla.sendMessage(from, {text:teks.trim() }, {contextInfo: {"mentionedJid": memberr}}) : nayla.sendMessage(from, {text:teks.trim()}, {quoted: nay, contextInfo: {"mentionedJid": memberr}})}					
const reply = (teksnya) => {
const translate = require('translate-google')
translate(teksnya, {to: bahasa}).then(res => {
nayla.sendMessage(from, { text: res },{ quoted: nay1});
}).catch(err => {
nayla.sendMessage(from, { text: teksnya },{ quoted: nay1});    
})
}; 
const isUrl = (url) => {return url.match(new RegExp(/https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&/=]*)/, 'gi'))}
const sendText = (teksnya, fiturnya) => {
const buttons = [
{buttonId: `.${fiturnya}`, buttonText: {displayText: `NEXT`}, type: 1},
]
const buttonMessage = {
text: "Loading...",footer: teksnya,buttons: buttons,headerType: 1}
nayla.sendMessage(from, buttonMessage, {quoted:nay1})
}
const prosess = (teksnya) => {
nayla.sendMessage(from, { text: teksnya },{ quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) },message: {"extendedTextMessage": {"text": `HY : ${pushname}\n❀ RUNTIME : ${kyun(runtime)}`, 'title':'2', 'jpegThumbnail': fs.readFileSync(`./media/image/prosess.jpg`)}}}})
    };
const errorr = (teksnya) => {
nayla.sendMessage(from, { text: teksnya },{ quoted: {key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: from } : {})},message: {"extendedTextMessage": {"text": `HY : ${pushname}\n❀ RUNTIME : ${kyun(runtime)}`, 'title':'2', 'jpegThumbnail': fs.readFileSync(`./media/image/error.jpg`)}}}})
};
const sukses = (teksnya) => {
    nayla.sendMessage(from, { text: teksnya }, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { liveLocationMessage: { caption: `Bot by RndyBotz` } } } })
};




    const verifstic = (teksnya) => {
        nayla.sendMessage(from, { text: teksnya }, {
            quoted: {
                key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message:
                {
                    "stickerMessage": {
                        "fileSha256": "uZiOJzqOvrOo2WGjnMKgX2MMQMyasT+ZDgqUczpIBmY=",
                        "pngThumbnail": fs.readFileSync(`./media/image/error.jpg`),
                        "mimetype": "image/webp",
                        "height": 64,
                        "width": 64,
                        "directPath": "/v/t62.15575-24/56110107_763365384384977_5720135628188301198_n.enc?oh=450f8f684b06f0ba2dbc9779e5f06774&oe=605B81EE",
                        "fileLength": "60206",
                        "firstFrameLength": 3626,
                        "isAnimated": false
                    }
                }
            }
        })
    };
    const verifvid = (teksnya) => {
        nayla.sendMessage(from, { text: teksnya }, {
            quoted: {
                key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 
                    "videoMessage": { 
                    "title": `title`,
                    "h": `h`,
                    'duration': '99999', 
                    'caption': `capt`,
                    'jpegThumbnail': fs.readFileSync(`./media/image/error.jpg`),
                           }
                          }
                         
            }
        })
    };
const veriftrol = (teksnya) => {
    nayla.sendMessage(from, { text: teksnya }, {
        quoted: {
            key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: {
                orderMessage: {
                    itemCount: 123,
                    status: 1,
                    surface: 1,
                    message: `ucapan : nama`, //Kasih namalu
                    orderTitle: `ucapan2 : nama2`,
                    thumbnail: fs.readFileSync(`./media/image/error.jpg`), //Gambarnye
                    sellerJid: '0@s.whatsapp.net'
                }
            }
        }})
    };
    const wellcome = (ucapan,nomor) => {
    nayla.sendMessage(from, { text: ucapan }, {
        quoted: {
            key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: {
                orderMessage: {
                    itemCount: 2022,
                    status: 1,
                    surface: 1,
                    message: nomor, //Kasih namalu
                    orderTitle: `ucapan2 : nama2`,
                    thumbnail: fs.readFileSync(`./media/image/error.jpg`), //Gambarnye
                    sellerJid: '0@s.whatsapp.net'
                }
            }
        }})
    };
    const verifloc = (teksnya) => {
        nayla.sendMessage(from, { text: teksnya }, {
            quoted: {
                key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: {
                    liveLocationMessage: {
                        caption: `ucapan : nama`,
                        jpegThumbnail: fs.readFileSync(`./media/image/error.jpg`)
                    }
                }
            }
        })
    };




    const verifdoc = (teksnya) => {
        nayla.sendMessage(from, { text: teksnya }, {
            quoted: {
                key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: from } : {}) },
                message: {
                    documentMessage: {
                        title: `title`,
                        jpegThumbnail: fs.readFileSync(`./media/image/error.jpg`)
                    }
                }
            }
            })
    };
    const verifgif = (teksnya) => {
        nayla.sendMessage(from, { text: teksnya }, {
            quoted: {
                key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: from } : {}) }, message: { 
                    "videoMessage": { 
                    "title": `title`,
                    "h": `h`,
                    'duration': '99999', 
                    'gifPlayback': 'true', 
                    'caption': `caption`,
                    'jpegThumbnail': fs.readFileSync(`./media/image/error.jpg`)
                           }
                          }
                         
                             }})
            };







const verifvn = (teksnya) => {
nayla.sendMessage(from, { text: teksnya },{ quoted: {key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: from } : {})},	 message: { 
    "audioMessage": {
             "mimetype":"audio/ogg; codecs=opus",
             "seconds": "99999",
             "ptt": "true"
                    }
                  } 
                 }})
};
const verifpict = (teksnya) => {
    nayla.sendMessage(from, { text: teksnya }, { quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: {
        "imageMessage": {
            "url": "https://mmg.whatsapp.net/d/f/At0x7ZdIvuicfjlf9oWS6A3AR9XPh0P-hZIVPLsI70nM.enc",
            "mimetype": "image/jpeg",
            "caption": 'quotes',
            "fileSha256": "+Ia+Dwib70Y1CWRMAP9QLJKjIJt54fKycOfB2OEZbTU=",
            "fileLength": "28777",
            "height": 1080,
            "width": 1079,
            "mediaKey": "vXmRR7ZUeDWjXy5iQk17TrowBzuwRya0errAFnXxbGc=",
            "fileEncSha256": "sR9D2RS5JSifw49HeBADguI23fWDz1aZu4faWG/CyRY=",
            "directPath": "/v/t62.7118-24/21427642_840952686474581_572788076332761430_n.enc?oh=3f57c1ba2fcab95f2c0bb475d72720ba&oe=602F3D69",
            "mediaKeyTimestamp": "1610993486",
            "jpegThumbnail": fs.readFileSync(`./media/image/error.jpg`),
            "scansSidecar": "1W0XhfaAcDwc7xh1R8lca6Qg/1bB4naFCSngM2LKO2NoP5RI7K+zLw=="
        }
    }} })
};


const txt = nay.message.conversation 
nayla.sendnew = async (satu, dua, tiga) => {return await generateWAMessage(satu, dua, {...tiga ,userJid: nayla.authState.creds.me.id,upload: nayla.waUploadToServer})}      
const sendMenu = async (satu, dua, tiga, empat) => {
var menu1 = await generateWAMessageFromContent(from, {
"templateMessage": {"hydratedTemplate": {...empat.message,"hydratedContentText": dua,"hydratedFooterText": tiga,"hydratedButtons": [
{"urlButton": {"displayText": "SOURCE CODE","url": "https://youtube.com/channel/UCeQaKIQQhDNHMOq_odQh5Sw"}},
{"urlButton": {"displayText": "OWNER","url": "https://wa.me/"+ nomerowner}},
{"quickReplyButton": {"displayText": "DONASI","id": `${prefix}donasi`}},
{"quickReplyButton": {"displayText": "MYGRUB","id": `${prefix}mygrub`,}},
{"quickReplyButton": {"displayText": "SYARAT & KETENTUAN","id": `${prefix}desk`}}
]}}}, {})
nayla.relayMessage(satu, menu1.message, { messageId: menu1.key.id })
}
const sendMenuu = async (satu, dua, tiga, empat) => {
var menuu1 = await generateWAMessageFromContent(from, {
"templateMessage": {"hydratedTemplate": {...empat.message,"hydratedContentText": dua,"hydratedFooterText": tiga,"hydratedButtons": [
{"urlButton": {"displayText": "SOURCE CODE","url": "https://youtube.com/channel/UCeQaKIQQhDNHMOq_odQh5Sw"}},
{"urlButton": {"displayText": "OWNER","url": "https://wa.me/"+ nomerowner}},
{"quickReplyButton": {"displayText": "ALLMENU","id": `${prefix}allmenu`}},
{"quickReplyButton": {"displayText": "ALLMENU","id": `${prefix}allmenu`}},
{"quickReplyButton": {"displayText": "ALLMENU","id": `${prefix}allmenu`}}
]}}}, {})
nayla.relayMessage(satu, menuu1.message, { messageId: menuu1.key.id })
}
const nextt = (satu, dua, tiga, empat) => {
const buttons0 = [{buttonId: `${prefix + satu}`, buttonText: {displayText:dua}, type: 1}]
const buttonMessage0 = {image: {url:tiga},caption: empat, footerText: 'Loading...',buttons: buttons0,headerType: 4}
nayla.sendMessage(from, buttonMessage0, {quoted:nay1})}

	
	
	
	
switch (cmd) {
case 'setbahasa':
if (!isOwner) return reply(respon.ownerbot(pushname));
if (!q) return nayla.sendMessage(from, { text : `listbahasa?\n${prefix}setbahasa id\n${prefix}setbahasa en`}, {quoted:nay1})
if ((args[0]) === 'id') {sukses("SUKSES")
bahasa = "id"
} else if ((args[0]) === 'en') {sukses("SUKSES")
bahasa = "en"
} else {
nayla.sendMessage(from, { text : `listbahasa?\n${prefix}setbahasa id\n${prefix}setbahasa en`}, {quoted:nay1})
}
case 'setprefix':
if (!isOwner) return reply(respon.ownerbot(pushname));
sukses("SUKSES")
prefix = args[0]
break
case 'promote':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('Tag orang yang ingin dipromosikan menjadi admin group');
const men = nay.message.extendedTextMessage.contextInfo.mentionedJid;
nayla.groupParticipantsUpdate(from, men,"promote");
break
case 'demote':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('Tag orang yang ingin di demote di group ini');
const mention = nay.message.extendedTextMessage.contextInfo.mentionedJid;
await nayla.groupParticipantsUpdate(from, mention,"demote");
break
case 'add':
try {
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
if (!q) return reply("Masukan nomor yang ingin ditambahkan di group\nex: !add 62881xxxxxxx")
nomor = `${args[0].replace(/ /g, '')}@s.whatsapp.net`
await nayla.groupParticipantsUpdate(from, [nomor],"add")
} catch (e) {
reply('Maaf error')
}
break
case 'kick':
try {
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('Tag orang yang ingin dikeluarkan dari group ini')
const mention = nay.message.extendedTextMessage.contextInfo.mentionedJid
await nayla.groupParticipantsUpdate(from, mention,"remove")
} catch (e) {
reply('Maaf error')
}
break
case 'resetlink':
case 'revoke':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
await nayla.groupRevokeInvite(from)
break
case 'linkgroup':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
const code = await nayla.groupInviteCode(from)
reply("https://chat.whatsapp.com/" + code)
break
case 'setdesc':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
if (!q) return reply(respon.notText(prefix,cmd, pushname));
nayla.groupUpdateDescription(from, q)
break
case 'setname':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
if (!q) return reply(respon.notText(prefix,cmd, pushname));
nayla.groupUpdateSubject(from, q);
break
case 'owner':
const vcard = 'BEGIN:VCARD\n'
+ 'VERSION:3.0\n' 
+ `FN:${namaowner}\n`
+ 'ORG:Ini saya;\n'
+ `TEL;type=CELL;type=VOICE;waid=${nomerowner}:+${nomerowner}\n`
+ 'END:VCARD';
nayla.sendMessage(from, { contacts: { contacts: [{ vcard }] }});
break
case 'donasi':
case 'donate':
const donasii =`${donasi}\n• PULSA ${pulsa}\n• DANA ${dana}\n• GOPAY ${gopay}`
reply(donasii)
break
case 'allhelp':
case 'allmenu':
const menu = `✑✑✑✑✑✑✑✑✑✑✑✑
•°”˜˜”°•.¸☆ ★ ☆¸.•°”˜˜”°•.¸☆
╔══╗╔═╗╔══╗╔══╗★ ★
║╔╗║║║║╚╗╔╝╠══║☆¸.•°*”
║╔╗║║║║─║║─║══╣★
╚══╝╚═╝─╚╝─╚══╝♡￥☆
✑✑✑✑✑✑✑✑✑✑✑✑
~ Heyy ${pushname} 👋
✑✑✑✑✑✑✑✑✑✑✑✑
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *MENU* ]
✄ *${prefix}donasi*
✄ *${prefix}owner*
✄ *${prefix}mygrub*
✄ *${prefix}listprem*
✄ *${prefix}getprem*
✄ *${prefix}iklan3*
✄ *${prefix}iklan2*
✄ *${prefix}iklan1*
✄ *${prefix}scbot*
✄ *${prefix}chatowner*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *OWNER MENU* ]
✄ *${prefix}setprefix*
✄ *${prefix}setbahasa*
✄ *${prefix}speed*
✄ *${prefix}addprem*
✄ *${prefix}dellprem*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *GROUP MENU* ]
✄ *${prefix}add*
✄ *${prefix}kick*
✄ *${prefix}promote*
✄ *${prefix}demote*
✄ *${prefix}resetlink*
✄ *${prefix}linkgroup*
✄ *${prefix}setname*
✄ *${prefix}setdesc*
✄ *${prefix}antilink*
✄ *${prefix}antitag*
✄ *${prefix}antivirtex*
✄ *${prefix}hidetag*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *AUDIO MENU* ]
✄ *${prefix}audio1*
✄ *${prefix}audio2*
✄ *${prefix}audio3*
✄ *${prefix}audio4*
✄ *${prefix}audio5*
✄ *${prefix}audio6*
✄ *${prefix}audio7*
✄ *${prefix}audio8*
✄ *${prefix}audio9*
✄ *${prefix}audio10*
✄ *${prefix}audio11*
✄ *${prefix}audio12*
✄ *${prefix}audio13*
✄ *${prefix}audio14*
✄ *${prefix}audio15*
✄ *${prefix}audio16*
✄ *${prefix}audio17*
✄ *${prefix}audio18*
✄ *${prefix}audio19*
✄ *${prefix}audio20*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *WALLPAPER* ]
✄ *${prefix}wallml*
✄ *${prefix}wallpubg*
✄ *${prefix}wallcode*
✄ *${prefix}wallrandom*
✄ *${prefix}wallneon*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *STICK-MENU* ]
✄ *${prefix}tampar*
✄ *${prefix}tendang*
✄ *${prefix}jijik*
✄ *${prefix}ketawa*
✄ *${prefix}diam*
✄ *${prefix}kaget*
✄ *${prefix}nangis*
✄ *${prefix}peluk*
✄ *${prefix}pukul*
✄ *${prefix}marah*
✄ *${prefix}takut*
✄ *${prefix}sedih*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *TAG-MENU* ]
✄ *${prefix}pakgirl*
✄ *${prefix}nolep*
✄ *${prefix}pakboy*
✄ *${prefix}jago*
✄ *${prefix}halal*
✄ *${prefix}pintar*
✄ *${prefix}bego*
✄ *${prefix}haram*
✄ *${prefix}sadgirl*
✄ *${prefix}sadboy*
✄ *${prefix}jelek*
✄ *${prefix}jahat*
✄ *${prefix}hebat*
✄ *${prefix}baik*
✄ *${prefix}cantik*
✄ *${prefix}wibu*
✄ *${prefix}beban*
✄ *${prefix}ganteng*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *CEK-MENU* ]
✄ *${prefix}pakgirlcek*
✄ *${prefix}nolepcek*
✄ *${prefix}pakboycek*
✄ *${prefix}jagocek*
✄ *${prefix}halalcek*
✄ *${prefix}pintarcek*
✄ *${prefix}begocek*
✄ *${prefix}haramcek*
✄ *${prefix}sadgirlcek*
✄ *${prefix}sadboycek*
✄ *${prefix}jelekcek*
✄ *${prefix}jahatcek*
✄ *${prefix}hebatcek*
✄ *${prefix}baikcek*
✄ *${prefix}cantikcek*
✄ *${prefix}wibucek*
✄ *${prefix}bebancek*
✄ *${prefix}gantengcek*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *TEXTPRO-MENU* ]
✄ *${prefix}berry*
✄ *${prefix}transformer*
✄ *${prefix}metal*
✄ *${prefix}peridot*
✄ *${prefix}halloween*
✄ *${prefix}thunder*
✄ *${prefix}toxic*
✄ *${prefix}sketch*
✄ *${prefix}magma*
✄ *${prefix}purple*
✄ *${prefix}circuit*
✄ *${prefix}cracked*
✄ *${prefix}juice*
✄ *${prefix}blue*
✄ *${prefix}metallic*
✄ *${prefix}impressive*
✄ *${prefix}scfi*
✄ *${prefix}horror*
✄ *${prefix}realistic*
✄ *${prefix}rainbow*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *HACK-MENU* ]
✄ *${prefix}hackmatahari*
✄ *${prefix}hackbulan*
✄ *${prefix}hackbapak*
✄ *${prefix}hacksatelit*
✄ *${prefix}hacklautan*
✄ *${prefix}hackfreefire*
✄ *${prefix}hackbts*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *RANDOM-MENU* ]
✄ *${prefix}artinama*
✄ *${prefix}artimimpi*
✄ *${prefix}resepmasakan*
✄ *${prefix}katajago*
✄ *${prefix}besarkecil*
✄ *${prefix}jumlahhuruf*
✄ *${prefix}jumlahangka*
✄ *${prefix}infogempa* 
✄ *${prefix}balikangka*
✄ *${prefix}wikipedia*
✄ *${prefix}balikhuruf*
✄ *${prefix}bilangangka*
✄ *${prefix}holoh*
✄ *${prefix}heleh*
✄ *${prefix}huluh*
✄ *${prefix}hilih*
✄ *${prefix}halah*
✄ *${prefix}kapital* 
✄ *${prefix}attp*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *SEARCH-MENU* ]
✄ *${prefix}sfile*
✄ *${prefix}rexdl*
✄ *${prefix}ytsearch*
✄ *${prefix}cersex*
✄ *${prefix}thelazy*
✄ *${prefix}shopee*
✄ *${prefix}amazon*
✄ *${prefix}arena*
✄ *${prefix}grubwa*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *NEWS-MENU* ]
✄ *${prefix}antara*
✄ *${prefix}okezone*
✄ *${prefix}kompas*
✄ *${prefix}berita*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *INFO-MENU* ]
✄ *${prefix}coronameninggal*
✄ *${prefix}infohoax*
✄ *${prefix}jadwalbola*
✄ *${prefix}jamdunia*
✄ *${prefix}jam*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *ISLAMI-MENU* ]
✄ *${prefix}kisahnabi*
✄ *${prefix}asmaulhusna*
✄ *${prefix}quran*
✄ *${prefix}hadist*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *NSFW-MENU* ]
✄ *${prefix}yuri*
✄ *${prefix}thighs*
✄ *${prefix}pussy*
✄ *${prefix}panties*
✄ *${prefix}orgy*
✄ *${prefix}ass*
✄ *${prefix}ahegao*
✄ *${prefix}bdsm*
✄ *${prefix}blowjob*
✄ *${prefix}cuckold*
✄ *${prefix}ero*
✄ *${prefix}cum*
✄ *${prefix}femdom*
✄ *${prefix}foot*
✄ *${prefix}gangbang*
✄ *${prefix}glasses*
✄ *${prefix}jahy*
✄ *${prefix}masturbation*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *NSFW-MENU* ]
✄ *${prefix}tebakgambar*
✄ *${prefix}tebaklirik*
✄ *${prefix}tebakkimia*
✄ *${prefix}tebakjenaka*
✄ *${prefix}tebakbendera*
✄ *${prefix}caklontong*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *NSFW-MENU* ]
✄ *${prefix}emojilg*
✄ *${prefix}emojipedia*
✄ *${prefix}emojimoji*
✄ *${prefix}emojijoy*
✄ *${prefix}emojiskype*
✄ *${prefix}emojifecabook*
✄ *${prefix}emojitwitter*
✄ *${prefix}emojiwhatsapp*
✄ *${prefix}emojimicrosoft*
✄ *${prefix}emojisamsung*
✄ *${prefix}emojigoogle*
✄ *${prefix}emojiapple*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *TRENDING* ]
✄ *${prefix}trenbekasi*
✄ *${prefix}trendepok*
✄ *${prefix}trenpekanbaru*
✄ *${prefix}trensurabaya*
✄ *${prefix}trenmakassar*
✄ *${prefix}trenbandung*
✄ *${prefix}trenjakarta*
✄ *${prefix}trenmedan*
✄ *${prefix}trenpalembang*
✄ *${prefix}trensemarang*
✄ *${prefix}trentangerang*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *KERANG AJAIB* ]
✄ *${prefix}berapa*
✄ *${prefix}siapa*
✄ *${prefix}kapan*
✄ *${prefix}dimana*
✄ *${prefix}apakah*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *QUOTESS NEW* ]
✄ *${prefix}quotesanime*
✄ *${prefix}quotesbucin*
✄ *${prefix}quoteskehidupan*
✄ *${prefix}quotesgalau*
✄ *${prefix}quotesrandom*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *DOWNLOAD* ]
✄ *${prefix}ytmp4*
✄ *${prefix}ytmp3*
✄ *${prefix}ytaudio*
✄ *${prefix}ytvideo*
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *SEPAKBOLA* ]
✄ *${prefix}rodri*
✄ *${prefix}vinicius*
✄ *${prefix}robert*
✄ *${prefix}erling*
✄ *${prefix}oliver*
✄ *${prefix}ricardo*
✄ *${prefix}mbappe*
✄ *${prefix}rashford*
✄ *${prefix}messi*
✄ *${prefix}ronaldo*
✑✑✑✑✑✑✑✑✑✑✑✑
✄ *TERAPKAN* [ 5M ]
✄ Memakai masker
✄ Mencuci tangan
✄ Menjaga jarak
✄ Menjauhi kerumunan
✄ Membatasi mobilitas
✑✑✑✑✑✑✑✑✑✑✑✑
=> [ *THX TO* ]
✄ *RIMURUBOTZ*
✄ *LORD RYNZ*
✄ *ADIWAJSHING*
✄ *MEGAWATI*
✑✑✑✑✑✑✑✑✑✑✑✑`
await sendMenu(from, menu, "Lightweight full-featured WhatsApp Web + Multi-Device API", await nayla.sendnew(from, {video: {url: "./media/video/menu.mp4", caption: menu}, gifPlayback: true}))
break
case 'menu':
menuu = `Halo *${pushname}*\nBOT(BUILD-OPERATE-TRANSFER) adalah program komputer yang dijalankan di Whatsapp yang khusus dibuat untuk melakukan pekerjaan-pekerjaan otomatis, BOT Whatsapp dirancang sedemikian rupa sehingga dapat digunakan dengan nyaman, dan kemungkinan memiliki sedikit bug, Adanya fitur dari bot WhatsApp ini tentu akan membantu anda untuk bersenang senang, dll`
await sendMenuu(from, menuu, `full-featured WhatsApp Web + Multi-Device API`, await nayla.sendnew(from, {video: {url: "./media/video/menuu.mp4", caption: menuu}, gifPlayback: true}))
break
case 'desk':
reply(`✑✑✑✑✑✑✑✑✑✑✑✑
✄ *PERATURAN*
✄ Bot ini tidak menyimpan media/foto yang anda kirimkan
✄ Gunakan bot ini sebaik mungkin
✄ Jangan spam fitur/command bot
✄ Bot ini hanya untuk hiburan semata, dan *tidak untuk dimakan*
✄ Bot ini sekedar bot, tidak dapet berbicara/melakukan hall yang berlebihan seperti manusia
✑✑✑✑✑✑✑✑✑✑✑✑
✄ *HUKUMAN*
✄ Owner berhak memberikan teguran hingga sanksi terhadap user yang melanggar peraturan di atas
✄ Melanggar peraturan di atas dapat mendapatkan sanksi seperti banned/block user
✑✑✑✑✑✑✑✑✑✑✑✑`)
break
case 'mygrub': case 'mygrup':
reply("Join-ya!?\n" + linkgrub)
break
case 'ping': case 'speed':
if (!isOwner) return reply(respon.ownerbot(pushname));
const speed = require('performance-now')
let timestampi = speed();
let latensii = speed() - timestampi
spd = `=> *SPEED* : ${latensii.toFixed(4)}`
reply(spd)
break			
case 'addprem':	
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isOwner) return reply(respon.ownerbot(pushname));
if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('Tag orang nya kak')
const meention = nay.message.extendedTextMessage.contextInfo.mentionedJid
prem.push(meention)
fs.writeFileSync('./lib/prem.json', JSON.stringify(prem))
sukses("SUKSES")
break				
case 'dellprem':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isOwner) return reply(respon.ownerbot(pushname));
if (nay.message.extendedTextMessage === undefined || nay.message.extendedTextMessage === null) return reply('Tag orang nya kak')
const meentionn = nay.message.extendedTextMessage.contextInfo.mentionedJid
prem.splice(meentionn, 1)
fs.writeFileSync('./lib/prem.json', JSON.stringify(prem))
sukses("SUKSES")
break
case 'listprem':
reply(prem)
break 
case 'getprem':
if (isPrem) return reply("Anda telah menjadi user premium sebelumnya")
if (!q) return reply("Silahkan masukkan kode premium, untuk mendapatkan kode premium silahkan hubungi owner")
if ((args[0]) === kodeprem) {
prem.push(`${sender.split("@")[0]}@s.whatsapp.net`)
fs.writeFileSync('./lib/prem.json', JSON.stringify(prem))
sukses("SUKSES")
} else {
reply("kode yang anda gunakan salah, untuk mendapatkan kode premium silahkan hubungi owner")
}
break
case 'iklan':
const buttons = [
{buttonId: `${prefix}iklan1`, buttonText: {displayText: 'IKLAN1'}, type: 1},
{buttonId: `${prefix}iklan2`, buttonText: {displayText: 'IKLAN2'}, type: 1},
{buttonId: `${prefix}iklan3`, buttonText: {displayText: 'IKLAN3'}, type: 1}
]
const p = {
text: `IKLAN BY ${namaowner}`,
footer: `Loading...`,
buttons: buttons,
headerType: 1
}
nayla.sendMessage(from, p)
break
case 'chat':
case 'chatowner':
if (!q) return reply("Text nya mana")
nayla.sendMessage(`${nomerowner}@s.whatsapp.net`, {text: `• *NAME* : ${pushname}\n• *MESSAGE* : ${q}`}, {quoted:nay1})
sukses("SUKSES")
break
case 'iklan1': 
reply(iklan.iklan1())
break
case 'iklan2': 
reply(iklan.iklan2())
break
case 'iklan3': 
reply(iklan.iklan3())
break
case 'rndy':
profilpp = sender.split("@")[0]+ '@c.us'
const ppUrl = await nayla.profilePictureUrl(profilpp, 'image')
nyz3 = await getBuffer(ppUrl)
nayla.sendMessage(from, {image : nyz3, caption: `ASU LU`}, {quoted: nay1}) 						
break
case 's':
case 'sticker':
case 'stiker':
case 'sgif':
case 'stickergif':
case 'stikergif':
try {
verifvid("[❗] SEDANG DIPROSES")	    
if (isMedia || isQuotedImage) {
var stream = await downloadContentFromMessage(nay.message.imageMessage || nay.message.extendedTextMessage?.contextInfo.quotedMessage.imageMessage, 'image')
var buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
fs.writeFileSync('./media/res_buffer.jpg', buffer)
const image = './media/res_buffer.jpg'
await ffmpeg(image)
.input(image)
.on('start', function (start) {
// console.log(colors.green.bold(`${start}`))
})
.on('error', function (error) {
reply("error")
 console.log(`${error}`)
})
.on('end', function () {
//console.log(colors.yellow('Selesai convert'))
nayla.sendMessage(from, { sticker: {url: './media/mysticker.webp'}, mimetype: 'image/webp' })
})
.addOutputOptions([`-vcodec`, `libwebp`, `-vf`, `scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse`])
.toFormat('webp')
.save('./media/mysticker.webp')
} else if (isMedia || isQuotedVideo) {
var stream = await downloadContentFromMessage(nay.message.videoMessage || nay.message.extendedTextMessage?.contextInfo.quotedMessage.videoMessage, 'video')
var buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])
}
fs.writeFileSync('./media/res_buffer.mp4', buffer)
const video = './media/res_buffer.mp4'
await ffmpeg(video)
.input(video)
.on('start', function (start) {
// console.log(colors.green.bold(`${start}`))
})
.on('error', function (error) {
reply("error")
 console.log(`${error}`)
})
.on('end', function () {
//console.log(colors.yellow('Selesai convert'))
nayla.sendMessage(from, { sticker: {url: './media/mysticker2.webp' }, mimetype: 'image/webp' })
})
.addOutputOptions(["-vcodec", "libwebp", "-vf", "scale='min(320,iw)':min'(320,ih)':force_original_aspect_ratio=decrease,fps=15, pad=320:320:-1:-1:color=white@0.0, split [a][b]; [a] palettegen=reserve_transparent=on:transparency_color=ffffff [p]; [b][p] paletteuse"])
.toFormat('webp')
.save('./media/mysticker2.webp')
} else {
reply(`Kirim foto/video dengan caption ${prefix}sticker`)
}
} catch (e) {
console.log(e)
error("ERROR")
}
break
case 'hidetag':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
if (!q) return reply("TEXT NYA MANA")
const id = uwong.map(v => v.id)
nayla.sendMessage(from, { text: `${q}`, mentions: id })
break
case 'antilink':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
const buttons12 = [
{buttonId: `${prefix}antilink off`, buttonText: {displayText: 'OFF'}, type: 1},
{buttonId: `${prefix}antilink on`, buttonText: {displayText: 'ON'}, type: 1}]
const pp = {
text: `ANTILINK ONLINE/OFLINE`,
footer: `Loading...`,
buttons: buttons12,
headerType: 1
}
if (!q) return nayla.sendMessage(from, pp)
if ((args[0]) === 'on') {
antilink.push(from)
fs.writeFileSync('./lib/antilink.json', JSON.stringify(antilink))
reply("SUKSES : ANTILINK ON")
} else if ((args[0]) === 'off') {
antilink.splice(from, 1)
fs.writeFileSync('./lib/antilink.json', JSON.stringify(antilink))
reply("SUKSES : ANTILINK OFF")
} else {
nayla.sendMessage(from, pp)
}
break 	
case 'antitag':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
const buttons132 = [
{buttonId: `${prefix}antitag off`, buttonText: {displayText: 'OFF'}, type: 1},
{buttonId: `${prefix}antitag on`, buttonText: {displayText: 'ON'}, type: 1}]
const pp1 = {
text: `ANTITAG ONLINE/OFLINE`,
footer: `Loading...`,
buttons: buttons132,
headerType: 1
}
if (!q) return nayla.sendMessage(from, pp1)
if ((args[0]) === 'on') {
antitag.push(from)
fs.writeFileSync('./lib/antitag.json', JSON.stringify(antitag))
reply("SUKSES : ANTITAG ON")
} else if ((args[0]) === 'off') {
antitag.splice(from, 1)
fs.writeFileSync('./lib/antitag.json', JSON.stringify(antitag))
reply("SUKSES : ANTITAG OFF")
} else {
nayla.sendMessage(from, pp1)
}
break 	
case 'antivirtex':
if (!isGroup) return reply(respon.onlyGroup(pushname));
if (!isGroupAdmins) return reply(respon.onlyAdmin(pushname));
if (!isBotGroupAdmins) return reply(respon.botAdmin(pushname));
const buttons123 = [
{buttonId: `${prefix}antivirtex off`, buttonText: {displayText: 'OFF'}, type: 1},
{buttonId: `${prefix}antivirtex on`, buttonText: {displayText: 'ON'}, type: 1}]
const pp12 = {
text: `ANTIVIRTEX ONLINE/OFLINE`,
footer: `Loading...`,
buttons: buttons123,
headerType: 1
}
if (!q) return nayla.sendMessage(from, pp12)
if ((args[0]) === 'on') {
antivirtex.push(from)
fs.writeFileSync('./lib/antivirtex.json', JSON.stringify(antivirtex))
reply("SUKSES : ANTIVIRTEX ON")
} else if ((args[0]) === 'off') {
antivirtex.splice(from, 1)
fs.writeFileSync('./lib/antivirtex.json', JSON.stringify(antivirtex))
reply("SUKSES : ANTIVIRTEX OFF")
} else {
nayla.sendMessage(from, pp12)
}
break
default: 
if (budy.includes("@")){
if (!isAntitag) return
nayla.sendMessage(from, {sticker : anti}, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...({}) }, message: { "extendedTextMessage": { "text": `STOP TAG TAG [ 🤬 ]`} } }}) 	
}            
if (budy.includes("https://")){
if (!isGroup) return
if (!isAntiLink) return
if (isGroupAdmins) return reply(`ADMIN😎💪`)
var Kick = `${sender.split("@")[0]}@s.whatsapp.net` 
setTimeout( () => {
nayla.groupParticipantsUpdate(from, [Kick],"remove")
}, 1000)
setTimeout( () => {
nayla.sendMessage(from, {sticker : anti}, {quoted: { key: { fromMe: false, participant: `0@s.whatsapp.net`, ...({}) }, message: { "extendedTextMessage": { "text": `ANTILINK [ ON ]`} } }}) 	
}, 0)
}
if (txt.length > 1500){
if (!isGroup) return
if (!isAntiVirtex) return
if (isGroupAdmins) return reply(`ADMIN😎💪`)
var kic = `${sender.split("@")[0]}@s.whatsapp.net`
setTimeout( () => {
nayla.groupParticipantsUpdate(from, [kic],"remove")
}, 0)
}
}
} catch (e) {
console.log(`${e}`) 
}
}