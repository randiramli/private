const express = require('express')
const os = require('os')
const app = express()
const port = 3000
const xnxx = require('./lib/xnxx.js')
 date = new Date();
detik = date.getSeconds();
menit = date.getMinutes();
jam = date.getHours();

time = `${jam}-${menit}-${detik}`

function kyun(seconds) {
	function pad(s) {
		return (s < 10 ? '0' : '') + s;
	}
	var hours = Math.floor(seconds / (60 * 60));
	var minutes = Math.floor(seconds % (60 * 60) / 60);
	var seconds = Math.floor(seconds % 60);

	//return pad(hours) + ':' + pad(minutes) + ':' + pad(seconds)
	return `${pad(hours)}Jam ${pad(minutes)}Menit ${pad(seconds)}Detik`
}
app.get('/', async (req, res) => {
	console.log(time)
	console.log(os.platform())
	console.log(kyun(os.uptime()))
 res.send(req.hostname)
  
})

app.get('/xnxxdl', async (req, res) => {
	url = req.query.url
	try {
		var hasil = await xnxx.xnxxdl(url)
	
		res.json(hasil)
		console.log(url)
	} catch (e) {
		console.log(e)
	}
	
	})
	app.get('/xnxxsearch', async (req, res) => {
	search = req.query.search
	try {
		var hasil = await xnxx.xnxxsearch(search)
	
		res.json(hasil)
		console.log(hasil)
	} catch (e) {
		console.log(e)
	}
	

  
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})